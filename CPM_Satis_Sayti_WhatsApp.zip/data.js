var DATA = JSON.parse(localStorage.getItem("DATA")) || {
  "Valyuta": [
    "50M pul - 1 AZN",
    "30K coin - 1 AZN",
    "500K coin - 2 AZN"
  ],
  "Hesablar": [
    "ID dəyişmə - 2 AZN",
    "Boş hesab yaratmaq - 1 AZN",
    "Full hesab (W16 yoxdur) - 8 AZN"
  ],
  "Maşın üçün": [
    "Xrom - 1 AZN",
    "Unikal HP - 1 AZN",
    "Bütün pullu diskləri açmaq - 1 AZN",
    "Miqalka - 1 AZN"
  ],
  "Əlavə": [
    "Crown almaq - 1 AZN",
    "İstədiyiniz maşını açmaq - 1 AZN",
    "Hesabınızı full etmək - 4 AZN",
    "İstədiyiniz bir maşına W16 qoşmaq - 1 AZN"
  ]
};
